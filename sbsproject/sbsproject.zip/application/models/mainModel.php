<?php

class mainModel extends CI_model
{
	
	

public	function  fetchtoken()
{

$data=$this->db->get('tokens');
return $data->result();

}


public function studentdetails($data)

{

    $status=$this->db->insert("studentdetails",$data);
	return $status;
}

public function saveattendance($data)
{

    $status=$this->db->insert("studentattendance",$data);
	return $status;

}




/// show users



}

?>