<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	
	public function index()
	{
		$this->load->view('index');
	}



	// this is the for logincheck auth




	public function logincheck()
{
$email=$this->input->post('email');
$password=$this->input->post('password');

$this->load->model('loginModel');
$token =$this->loginModel->checklogin($email,$password);
if($token)
{

 $session_data = array('username' =>$email);
 $this->session->set_userdata($session_data);

redirect(base_url().'index.php/Admin/dashboard');
}
else
{
 redirect(base_url().'index.php/Admin/index');

}

}

// dashboard


public function dashboard()
{

if($this->session->userdata('username')!==null)	
{
$check =$this->session->flashdata('status');

if($check==1)
{
	echo "<script>alert('data inserted');</script>";
}
// $this->load->model('mainModel');
// $value= $this->mainModel->getClassdetails();
// $total= $this->mainModel->totalregistredstudent();
// echo"<script> alert('$total');</script>";

// $data = array(
// 'classdata' => $value,
// 'kalka' => $total,

// );
$this->load->view('dashboard');

}	
else
{

redirect(base_url().'index.php/Admin/index');
}



}

// this is the game function




/// this is the user pannel

public function userpannel()
{

	
	if($this->session->userdata('username')!=null)
	{

		$this->load->view('userpannel');
	}
	else
	{

		redirect(base_url().'index.php/Admin/index');
	}

}

/// App <setting class=""></setting>


public function appsetting()
{


	if($this->session->userdata('username')!=null)
	{

		$this->load->view('appsetting');
	}
	else
	{

		redirect(base_url().'index.php/Admin/index');
	}


}


//play console

public function playconsole()
{


	if($this->session->userdata('username')!=null)
	{

		$this->load->view('playconsole');
	}
	else
	{

		redirect(base_url().'index.php/Admin/index');
	}


}

public function admobpannel()
{


	if($this->session->userdata('username')!=null)
	{

		$this->load->view('admobpannel');
	}
	else
	{

		redirect(base_url().'index.php/Admin/index');
	}



}

// send notification 


public function sendNotification()
{


	$this->load->model('mainModel');
	$tokens= $this->mainModel->fetchtoken();
	$title=$this->input->post('title');
	$messsage=$this->input->post('message');
	$arraysize=sizeof($tokens);
	$check=false;
	foreach($tokens as $row)
	{
		print($row->token);


     $url ="https://fcm.googleapis.com/fcm/send";
	
	  $fields=array(
	"to"=>$row->token,
	"notification"=>array(
		"body"=> $messsage,
		"title"=>$title,
		"icon"=>"http://www.kalkaprasad.com/assets/images/kalka.png",
		"priority" =>"high",
		"click_action"=>""
	)

);

$headers=array(
	'Authorization: key=AAAAaUoROYg:APA91bHb547DsJ_dTdV8kwJFXS8F-SDrkqzwGIYl-jbt6sZuv5mxmzVnZvQ4od6_2SdExpsWn3SjRRM1XCYFIXUb2HjnAJPysY2kWn18YRn45Fnl-kpmUNqxn2wOWhFnIxygKnutlybO',
	'Content-Type:application/json'
);

$ch=curl_init();
curl_setopt($ch,CURLOPT_URL,$url);
curl_setopt($ch,CURLOPT_POST,true);
curl_setopt($ch,CURLOPT_HTTPHEADER,$headers);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch,CURLOPT_POSTFIELDS,json_encode($fields));
$result=curl_exec($ch);
print_r($result);
curl_close($ch);
$check=true;
	


	}


	if($check==true)
	{
		$status="success";
		echo json_encode($status);
	}
	else{
		$status="failed";
		echo json_encode($status);
	}
	
}


// show usersd...


}
// end 

