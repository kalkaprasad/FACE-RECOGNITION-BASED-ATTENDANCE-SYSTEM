<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Api extends CI_Controller {



public function studentdetails()
{
    $this->load->model('mainModel');
    $roll=$this->input->post('rollno');
    $name=$this->input->post('name');
    $email=$this->input->post('email');
    $phone=$this->input->post('phone');
    $fatheremail=$this->input->post('fatheremail');
    $password=$this->input->post('password');
    $date=$this->input->post('date');

    $data=array(
        'rollno'=>$roll,
        'name'=>$name,
        'email'=>$email,
        'phone'=>$phone,
        'fatheremail'=>$fatheremail,
        'password'=>$password,
        'date'=>$date);
 
        $status=$this->mainModel->studentdetails($data);
        if($status==true)
        {
            echo"success";

        }
        else{
            echo" failed";
        }

      
}


public function attendancedata()
{

 $this->load->model('mainModel');

 $roll=$this->input->post('rollno');
 $name=$this->input->post('name');
 $date=$this->input->post('date');
 $email=$this->input->post('email');
 $time=$this->input->post('time');
 $status=$this->input->post('status');


 $data=array(
    'rollno'=>$roll,
    'name'=>$name,
    'email'=>$email,
    'status'=>$status,
    'time'=>$time,
    'date'=>$date);


    $status=$this->mainModel->saveattendance($data);
    if($status==true)
    {
        echo"success";

    }
    else{
        echo" failed";
    }



}

}