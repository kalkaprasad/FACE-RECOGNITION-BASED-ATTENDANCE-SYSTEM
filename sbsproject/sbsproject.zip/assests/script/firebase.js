// Your web app's Firebase configuration
// var firebaseConfig = {
//     apiKey: "AIzaSyDSZi5uMm0nm58SsKcDU_TDVWH8An881AY",
//     authDomain: "deepak-97cbb.firebaseapp.com",
//     databaseURL: "https://deepak-97cbb.firebaseio.com",
//     projectId: "deepak-97cbb",
//     storageBucket: "deepak-97cbb.appspot.com",
//     messagingSenderId: "452214208904",
//     appId: "1:452214208904:web:d4795fa7544783b1dc223d",
//     measurementId: "G-GY9KS5N24L"
//   };
//   // Initialize Firebase
 // Your web app's Firebase configuration
  // For Firebase JS SDK v7.20.0 and later, measurementId is optional
  var firebaseConfig = {
    apiKey: "AIzaSyD8MkBUQfGL4oS1bPdJS_HVYingYibc3r8",
    authDomain: "chatapp-c7408.firebaseapp.com",
    databaseURL: "https://chatapp-c7408.firebaseio.com",
    projectId: "chatapp-c7408",
    storageBucket: "chatapp-c7408.appspot.com",
    messagingSenderId: "1024452676179",
    appId: "1:1024452676179:web:50d801213bf06fcbac54a6",
    measurementId: "G-B8YB83JCLZ"
  };
  // Initialize Firebase
  // firebase.initializeApp(firebaseConfig);

// Initialize Firebase
